require('dotenv').config();
const { Bot, InlineKeyboard } = require('grammy');

const token = process.env.BOT_API_KEY; 
const bot = new Bot(token);

const userMap = new Map(); 

const menuKeyboard = new InlineKeyboard()
  .text('Играть', 'play');

const gameKeyboard = new InlineKeyboard()
  .text('Орёл 🦅', 'orel')
  .text('Решка 🪙', 'reshka')
  .row()
  .text('Статистика', 'stat');

const replayKeyboard = new InlineKeyboard()
  .text('Сыграть ещё', 'replay');

function saveUser(user_id) {
  if (!userMap.has(user_id)) {
    userMap.set(user_id, { win: 0, lose: 0 });
    console.log('Пользователь сохранен:', user_id);
  }
}

function changeUserStat(user_id, isWin) {
  let user = userMap.get(user_id);
  if (!user) {
    saveUser(user_id);
    user = userMap.get(user_id);
  }
  if (isWin) {
    user.win += 1;
  } else {
    user.lose += 1;
  }
  userMap.set(user_id, user);
  console.log('Пользователь обновился:', { user_id, ...user });
}

bot.command('start', async (ctx) => {
  saveUser(ctx.message.from.id);
  await ctx.reply('Добро пожаловать в игру «Орёл или решка»!', {
    reply_markup: menuKeyboard,
  });
});

bot.callbackQuery('play', async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx.deleteMessage();
  await ctx.reply('Выберите сторону:', { reply_markup: gameKeyboard });
});

bot.callbackQuery('replay', async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx.deleteMessage();
  await ctx.reply('Повторим игру:', { reply_markup: gameKeyboard });
});

bot.callbackQuery(['orel', 'reshka'], async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx.deleteMessage();

  const user_id = ctx.from.id;
  saveUser(user_id);

  const num = Math.random();
  const isWin = num >= 0.5;
  const emojiWin = '🎉';
  const emojiLose = '🙃';

  if (ctx.callbackQuery.data === 'orel') {
    if (isWin) {
      changeUserStat(user_id, true);
      await ctx.reply(`${emojiWin} Вы выбрали «Орёл» и победили!`, {
        reply_markup: replayKeyboard,
      });
    } else {
      changeUserStat(user_id, false);
      await ctx.reply(`${emojiLose} Вы выбрали «Орёл», но проиграли!`, {
        reply_markup: replayKeyboard,
      });
    }
  } else if (ctx.callbackQuery.data === 'reshka') {
    if (!isWin) {
      changeUserStat(user_id, true);
      await ctx.reply(`${emojiWin} Вы выбрали «Решка» и победили!`, {
        reply_markup: replayKeyboard,
      });
    } else {
      changeUserStat(user_id, false);
      await ctx.reply(`${emojiLose} Вы выбрали «Решка», но проиграли!`, {
        reply_markup: replayKeyboard,
      });
    }
  }
});

bot.command('stat', async (ctx) => {
  const user_id = ctx.from.id;
  if (!userMap.has(user_id)) {
    saveUser(user_id);
  }
  const user = userMap.get(user_id);
  await ctx.reply(`Ваша статистика:\n🔹 Побед: ${user.win}\n🔹 Поражений: ${user.lose}`, {
    reply_markup: menuKeyboard,
  });
});

bot.start();


